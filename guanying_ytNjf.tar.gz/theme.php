<?php
/**
 * 导航主题 - Typecho 卡片式导航展示主题
 * 
 * @package Typecho Nav Theme
 * @author Your Name
 * @version 1.0.0
 * @link https://example.com
 * @description 一个仿硬核指南风格的卡片式导航主题，支持自定义图标、平台标识和自动获取网站图标
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>
