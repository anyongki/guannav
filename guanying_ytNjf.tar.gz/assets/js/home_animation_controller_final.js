(function() {
    const handleCards = () => {
        const cards = document.querySelectorAll('.card');
        const isHomePage = window.location.hash === '' || window.location.hash === '#';

        if (isHomePage) {
            cards.forEach(card => {
                if (card.classList.contains('fade-in-up') || card.style.opacity !== '1') {
                    card.style.opacity = '1';
                    card.style.animation = 'none';
                    card.classList.remove('fade-in-up');
                }
            });
        } else {
            // 分类页逻辑：仅对尚未处理的卡片应用观察
            const observerOptions = {
                root: null,
                rootMargin: '0px',
                threshold: 0.1
            };

            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('fade-in-up');
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);

            cards.forEach(card => {
                if (!card.classList.contains('fade-in-up') && !card.dataset.observed) {
                    card.style.opacity = '0';
                    card.dataset.observed = 'true';
                    observer.observe(card);
                }
            });
        }
    };

    // 1. 初始执行
    handleCards();

    // 2. 监听 DOM 变化（处理 SPA 动态加载）
    const mutationObserver = new MutationObserver((mutations) => {
        let shouldHandle = false;
        mutations.forEach(mutation => {
            if (mutation.addedNodes.length > 0) {
                shouldHandle = true;
            }
        });
        if (shouldHandle) handleCards();
    });

    mutationObserver.observe(document.body, {
        childList: true,
        subtree: true
    });

    // 3. 监听 Hash 变化（处理 SPA 页面切换）
    window.addEventListener('hashchange', handleCards);
})();
