document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.card');
    const isHomePage = window.location.hash === '' || window.location.hash === '#';

    if (isHomePage) {
        // 如果是首页，直接显示所有卡片，不应用动画
        cards.forEach(card => {
            card.style.opacity = '1';
            card.style.animation = 'none';
        });
    } else {
        // 如果不是首页（分类页），则使用 IntersectionObserver 延迟加载动画
        const observerOptions = {
            root: null, // 视口是根
            rootMargin: '0px',
            threshold: 0.1 // 10%可见时触发
        };

        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // 元素进入视口，添加动画类
                    entry.target.classList.add('fade-in-up');
                    // 停止观察，避免重复触发
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        cards.forEach(card => {
            // 初始时设置透明，等待 IntersectionObserver 触发
            card.style.opacity = '0';
            observer.observe(card);
        });
    }
});
